# ControlHub — GUI Prototype

A complete, clickable **front-end draft** of every screen in **ControlHub**, an enterprise
Capital Markets **GRC** (Governance, Risk & Compliance) platform. Built from `../ch_rough.txt`.

This is a **visual/UX draft only** — static HTML with realistic sample data and mocked
autocomplete/chat/routing. It maps 1:1 to the planned Django + HTMX + Tailwind templates.

## Run it

The browser blocks `file://` for some features, so serve the folder over HTTP:

```bash
cd controlhub-mockups
python -m http.server 8756
```

Then open **http://localhost:8756/index.html**.

## Start here

- **`index.html`** — the landing page. A **search that autocompletes to policy & procedure
  docs**, plus an **AI chat** that navigates you ("chat to go where you want").
  - Try the search: type `exec`, `P&L`, `OSFI` → grouped doc suggestions → opens the viewer.
  - Try the chat: *"take me to NBC proposals pending risk review"* → lands on the NBC queue
    pre-filtered to Risk Review (mirrors the spec's Agentic Router / `HX-Redirect`).

## The shell (every in-app page)

Injected automatically by `assets/ch.js`:
- **Left sidebar** grouped by Django app / phase.
- **Top bar:** global policy search (same autocomplete), **AI chat** (slide-over),
  **⌘K / Ctrl-K command palette**, **theme toggle** (light = clean SaaS · dark = institutional),
  **role switcher** (Standard / Supervision / Trader / HR / Admin) that shows/hides nav to
  demonstrate the RBAC access matrix, and a user menu.

## Screen index

| Phase | Screen | File |
|---|---|---|
| — | Landing (search + AI chat) | `index.html` |
| — | Universal Search (Google-style, faceted) | `app/search.html` |
| — | Login / SSO | `app/login.html` |
| — | 403 Forbidden (permission denied) | `app/403.html` |
| 1 · Core | Dashboard (customizable widgets + scope) | `app/dashboard.html` |
| 1 · Core | Users & Roles | `app/users.html` |
| 1 · Core | Access Control Matrix (RBAC) | `app/rbac.html` |
| 2 · Aggregator/HR | Universal To-Do inbox | `app/todo.html` |
| 2 · Aggregator/HR | Task detail | `app/task-detail.html` |
| 2 · HR | Job Mandates | `app/hr-mandates.html` |
| 2 · HR | Absence Tracking | `app/hr-absence.html` |
| 2 · HR | My Organization (HR reporting-line tree) | `app/hierarchy.html` |
| 3 · Projects | New Business Committee (FSM queue) | `app/nbc.html` |
| 3 · Projects | NBC proposal detail (state machine) | `app/nbc-detail.html` |
| 3 · Projects | Project Kanban board | `app/kanban.html` |
| 3 · Projects | Program Gantt | `app/gantt.html` |
| 3 · Projects | Role Attestations | `app/attestations.html` |
| 4 · Trading Ops | P&L Attestations (sign-off) | `app/pnl.html` |
| 4 · Trading Ops | Trade Exceptions (commentary rule) | `app/exceptions.html` |
| 4 · Trading Ops | Clear Exception form | `app/exception-clear.html` |
| 4 · Trading Ops | Credit Limits (90% alert) | `app/credit-limits.html` |
| 5 · Governance | WSP / Policy Library | `app/wsp.html` |
| 5 · Governance | Document viewer | `app/wsp-viewer.html` |
| 5 · Governance | OSFI Control Mapping (B-13 / E-23) | `app/osfi.html` |
| 5 · Governance | ATARI Algorithm Registry | `app/atari.html` |
| 5 · Governance | Immutable change history | `app/atari-history.html` |
| 6 · Analytics | Adherence Scorecard | `app/scorecard.html` |
| 6 · Analytics | Hierarchy Roll-ups (aggregate by desk/dept/entity/region) | `app/rollups.html` |

## Notable interactions to try

- **Customizable dashboard** (`dashboard.html`) — widget views into every section. **Add/remove**
  widgets from a catalog, **reorder** (drag or up/down), and **scope** the whole board: *Just me*,
  a hand-picked *list of people*, or *My team* drilled 1..N levels down the reporting line — scoped
  widgets recompute for that set. Layout + scope persist in localStorage. Backed by `CH.WIDGETS`,
  `CH.scopePeople`, `CH.scopeStats`, `CH.chainToDepth` in `ch-data.js`.


- **Universal Search** (`search.html`) — a dedicated Google-style page: live results fanned into
  sections (Smart actions · Pages · Policies · People · Records), section facets + a progressive
  "refine" filter, keyboard nav, and an AI bridge — narrowing until one **path to take** remains.
  The top-bar search, the landing search, and ⌥Enter all funnel here (`search.html?q=…`); every
  search box shows a "Search everywhere for …" option.
- **Omni ask-bar** (top-bar, every in-app page) — one input that blends **ask + search**. Typing
  drops an inline answer surface: an AI reply with live data (e.g. "4 overdue attestations…"), a
  primary action, actionable result cards (Sign / Clear / View), blended search results and
  "did you mean" chips. The bottom-right **Ask AI** button and the top-bar spark icon open it.
  Backed by `CH.ask(q)` in `ch-data.js`. (This replaced the old chat slide-over.)
- **Chat-to-navigate** (landing page) — routes utterances to the right screen + filter.
- **⌘K / Ctrl-K** — command palette jumps to any page or policy doc.
- **Theme toggle** — every screen is styled for both light and dark.
- **Role switcher** — change acting role; watch sidebar items appear/disappear (RBAC).
- **Trade Exceptions → Clear** — the *Clear* button stays disabled until commentary is entered
  (the enforced-commentary control).
- **Credit Limits** — the ≥90% utilization alert banner + escalation.
- **ATARI history** — append-only audit diffs (who changed which parameter, to the millisecond).
- **My Organization** — the HR reporting-line tree: a manager sees their entire downward chain
  with each person's GRC status; manager nodes roll up their team. (You only see your own line.)
- **Hierarchy Roll-ups** — the same org roster (`CH.PEOPLE`) sliced by *custom hierarchies*:
  switch dimension (Trading Desk · Department · Legal Entity · Region) to aggregate adherence,
  overdue attestations and open exceptions, then drill into each group.

## Files

```
controlhub-mockups/
  index.html            landing (search + AI chat)
  assets/
    ch.css              design tokens + all components (light & dark)
    ch.js               shell injection, theme, role, autocomplete, chat, ⌘K palette
    ch-data.js          nav tree, policy-doc index, chat intent→route map
  app/                  all in-app screens (share the shell)
  README.md
```

## What's mocked vs. real

- **Real:** all layouts, both themes, autocomplete filtering, chat intent routing, command
  palette, role-based nav filtering, the clear-exception validation, query-param deep-link filters.
- **Mocked:** all data is hard-coded sample data; there is no backend, database, auth, or API.
  Sign-off / approve / export buttons are illustrative.

---
*Draft for design review. Next step: port these screens to Django templates (apps: `core`,
`aggregator`, `hr`, `projects`, `trading_ops`, `governance`, `scorecard`).*
