/* ControlHub prototype — shell + interactions
 * Injects the nav shell into any page containing [data-shell],
 * and wires theme, role, search autocomplete, chat, and ⌘K palette.
 * Also exposes reusable helpers (CH.attachAutocomplete, CH.botAnswer)
 * for the standalone landing / login pages.
 */
(function () {
  window.CH = window.CH || {};
  CH.base = window.CH_BASE || ''; // '' for /app pages, 'app/' for landing

  /* -------------------- icons (feather-style) -------------------- */
  var IP = {
    home:'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z|M9 22V12h6v10',
    users:'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2|@9,7,4|M23 21v-2a4 4 0 0 0-3-3.87|M16 3.13a4 4 0 0 1 0 7.75',
    shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z|M9 12l2 2 4-4',
    inbox:'M22 12h-6l-2 3h-4l-2-3H2|M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z',
    briefcase:'#2,7,20,14,2|M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16',
    calendar:'#3,4,18,18,2|M16 2v4|M8 2v4|M3 10h18',
    gavel:'#8,4,12,4,1|M6 6l6 6|M2 20h9|M14 8l-9 9|M13 3l8 8',
    columns:'#3,4,18,16,2|M12 4v16',
    timeline:'M22 12h-4l-3 9L9 3l-3 9H2',
    signature:'M12 20h9|M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',
    coins:'@8,8,7|M15.5 3.5a7 7 0 0 1 0 13|M6 8v.01|M6 12h4',
    alert:'M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z|M12 9v4|M12 17h.01',
    gauge:'M12 12l4-2|M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z|M12 12v.01',
    book:'M4 19.5A2.5 2.5 0 0 1 6.5 17H20|M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z',
    scale:'M12 3v18|M5 21h14|M7 8l-4 6h8zM17 8l-4 6h8z|M7 8V6|M6 6h12',
    cpu:'#4,4,16,16,2|#9,9,6,6,1|M9 1v3|M15 1v3|M9 20v3|M15 20v3|M20 9h3|M20 14h3|M1 9h3|M1 14h3',
    chart:'M3 3v18h18|M7 14l3-3 3 3 5-6',
    search:'@11,11,7|M21 21l-4.35-4.35',
    chat:'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
    sun:'@12,12,4|M12 1v2|M12 21v2|M4.2 4.2l1.4 1.4|M18.4 18.4l1.4 1.4|M1 12h2|M21 12h2|M4.2 19.8l1.4-1.4|M18.4 5.6l1.4-1.4',
    moon:'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z',
    command:'M18 3a3 3 0 0 0-3 3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 0 0 3-6z',
    bell:'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9|M13.7 21a2 2 0 0 1-3.4 0',
    plus:'M12 5v14|M5 12h14',
    check:'M20 6L9 17l-5-5',
    x:'M18 6L6 18|M6 6l12 12',
    chevron:'M9 18l6-6-6-6',
    download:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4|M7 10l5 5 5-5|M12 15V3',
    filter:'M22 3H2l8 9.46V19l4 2v-8.54z',
    external:'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6|M15 3h6v6|M10 14L21 3',
    clock:'@12,12,9|M12 7v5l3 2',
    lock:'#3,11,18,11,2|M7 11V7a5 5 0 0 1 10 0v4',
    send:'M22 2L11 13|M22 2l-7 20-4-9-9-4z',
    sparkles:'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z',
    menu:'M3 12h18|M3 6h18|M3 18h18',
    dot:'@12,12,3',
    file:'M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z|M13 2v7h7',
    building:'#3,3,18,18,2|M9 22v-4h6v4|M9 7h.01|M15 7h.01|M9 12h.01|M15 12h.01',
    sitemap:'#8,2,8,5,1|#3,17,6,5,1|#15,17,6,5,1|M12 7v5|M6 17v-2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v2',
    layers:'M12 2l10 5-10 5-10-5 10-5z|M2 17l10 5 10-5|M2 12l10 5 10-5'
  };
  function iconInner(spec) {
    return spec.split('|').map(function (p) {
      if (p[0] === '@') { var a = p.slice(1).split(','); return '<circle cx="'+a[0]+'" cy="'+a[1]+'" r="'+a[2]+'"/>'; }
      if (p[0] === '#') { var b = p.slice(1).split(','); return '<rect x="'+b[0]+'" y="'+b[1]+'" width="'+b[2]+'" height="'+b[3]+'" rx="'+(b[4]||0)+'"/>'; }
      return '<path d="'+p+'"/>';
    }).join('');
  }
  CH.icon = function (name, size) {
    var s = IP[name] || IP.dot;
    return '<svg viewBox="0 0 24 24" width="'+(size||18)+'" height="'+(size||18)+'" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+iconInner(s)+'</svg>';
  };

  /* -------------------- theme -------------------- */
  CH.getTheme = function () { return localStorage.getItem('ch-theme') || 'light'; };
  CH.applyTheme = function () { document.documentElement.classList.toggle('dark', CH.getTheme() === 'dark'); };
  CH.toggleTheme = function () {
    localStorage.setItem('ch-theme', CH.getTheme() === 'dark' ? 'light' : 'dark');
    CH.applyTheme();
    document.querySelectorAll('[data-theme-ico]').forEach(function (el) {
      el.innerHTML = CH.icon(CH.getTheme() === 'dark' ? 'sun' : 'moon');
    });
  };
  CH.applyTheme();

  /* -------------------- role -------------------- */
  CH.getRole = function () { return localStorage.getItem('ch-role') || 'Admin'; };
  CH.setRole = function (r) { localStorage.setItem('ch-role', r); location.reload(); };
  CH.canSee = function (item) {
    if (!item.roles) return true;
    var r = CH.getRole();
    return r === 'Admin' || item.roles.indexOf(r) !== -1;
  };

  CH.go = function (route) { window.location.href = CH.base + route; };
  CH.getParam = function (k) { return new URLSearchParams(location.search).get(k); };
  CH.esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]; }); };

  /* -------------------- autocomplete (policy/procedure docs) ------ */
  CH.attachAutocomplete = function (input, box) {
    var items = [], active = -1;
    function render(q) {
      var ql = q.toLowerCase().trim();
      var matches = ql ? CH.DOCS.filter(function (d) {
        return d.title.toLowerCase().indexOf(ql) !== -1 || d.id.toLowerCase().indexOf(ql) !== -1 || d.cat.toLowerCase().indexOf(ql) !== -1;
      }).slice(0, 7) : [];
      items = matches; active = -1;
      var seeAll = ql ? '<div class="ch-ac-item" data-seeall="1" style="border-top:1px solid var(--border)">'
        + '<span class="code" style="color:var(--accent)">↵</span>'
        + '<span class="t" style="color:var(--accent)">Search everywhere for “' + CH.esc(q.trim()) + '”</span>'
        + '<span class="c">all sections</span></div>' : '';
      function wireItems() {
        box.querySelectorAll('.ch-ac-item').forEach(function (el) {
          el.addEventListener('mousedown', function (e) {
            e.preventDefault();
            if (el.dataset.seeall) CH.go('search.html?q=' + encodeURIComponent(input.value.trim()));
            else CH.go('wsp-viewer.html?doc=' + el.dataset.id);
          });
        });
      }
      if (!matches.length) {
        if (seeAll) { box.innerHTML = seeAll; box.classList.add('open'); wireItems(); }
        else { box.classList.remove('open'); box.innerHTML = ''; }
        return;
      }
      var byCat = {};
      matches.forEach(function (m) { (byCat[m.cat] = byCat[m.cat] || []).push(m); });
      var html = '';
      Object.keys(byCat).forEach(function (cat) {
        html += '<div class="ch-ac-cat">' + cat + '</div>';
        byCat[cat].forEach(function (d) {
          var gi = matches.indexOf(d);
          html += '<div class="ch-ac-item" data-i="'+gi+'" data-id="'+d.id+'">'
            + '<span class="code">'+d.id+'</span>'
            + '<span class="t">'+CH.esc(d.title)+'</span>'
            + '<span class="c">'+d.owner+'</span></div>';
        });
      });
      box.innerHTML = html + seeAll; box.classList.add('open');
      wireItems();
    }
    input.addEventListener('input', function () { render(input.value); });
    input.addEventListener('focus', function () { if (input.value) render(input.value); });
    input.addEventListener('blur', function () { setTimeout(function () { box.classList.remove('open'); }, 150); });
    input.addEventListener('keydown', function (e) {
      var els = box.querySelectorAll('.ch-ac-item');
      if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, els.length - 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, 0); }
      else if (e.key === 'Enter') {
        var sel = box.querySelectorAll('.ch-ac-item')[active];
        if (sel && sel.dataset.seeall) { CH.go('search.html?q=' + encodeURIComponent(input.value.trim())); return; }
        if (active >= 0 && items[active]) { CH.go('wsp-viewer.html?doc=' + items[active].id); return; }
        if (input.value.trim()) CH.go('search.html?q=' + encodeURIComponent(input.value.trim())); return;
      }
      else return;
      els.forEach(function (el, i) { el.classList.toggle('active', i === active); });
    });
  };

  /* -------------------- chat router (mock agentic navigation) ---- */
  CH.botAnswer = function (text) {
    var intent = CH.resolveIntent(text);
    if (intent) return { html: intent.say, route: intent.route };
    return { html: "I can route you anywhere in ControlHub. Try: “open trade exceptions”, “P&L attestations”, “NBC proposals in risk review”, “credit limits”, “find the best execution policy”, or “my scorecard”.", route: null };
  };

  /* ===================================================================
   *  SHELL INJECTION
   * =================================================================*/
  function buildShell() {
    var shell = document.querySelector('[data-shell]');
    if (!shell) return;
    var pageId = shell.dataset.page || '';
    var title = shell.dataset.title || 'ControlHub';
    var sub = shell.dataset.sub || '';
    var group = '';
    var content = shell.innerHTML;

    // sidebar
    var navHtml = '';
    CH.NAV.forEach(function (g) {
      var visible = g.items.filter(CH.canSee);
      if (!visible.length) return;
      navHtml += '<div class="ch-nav-group"><div class="ch-nav-title">' + g.group + '</div>';
      visible.forEach(function (it) {
        if (it.id === pageId) group = g.group;
        navHtml += '<a class="ch-nav-item' + (it.id === pageId ? ' active' : '') + '" href="' + it.href + '">'
          + CH.icon(it.icon, 16) + '<span>' + it.label + '</span>'
          + (it.badge ? '<span class="ch-nav-badge">' + it.badge + '</span>' : '')
          + '</a>';
      });
      navHtml += '</div>';
    });

    var roleOpts = CH.ROLES.map(function (r) {
      return '<option' + (r === CH.getRole() ? ' selected' : '') + '>' + r + '</option>';
    }).join('');

    var themeIco = CH.icon(CH.getTheme() === 'dark' ? 'sun' : 'moon');

    var app = document.createElement('div');
    app.className = 'ch-app';
    app.innerHTML =
      '<aside class="ch-sidebar">'
        + '<a class="ch-brand" href="dashboard.html">'
          + '<span class="ch-brand-mark">C</span>'
          + '<span><span class="ch-brand-name">ControlHub</span><br><span class="ch-brand-sub">GRC Platform</span></span>'
        + '</a>'
        + '<nav class="ch-nav">' + navHtml + '</nav>'
      + '</aside>'
      + '<div class="ch-main">'
        + '<header class="ch-topbar">'
          + '<div class="ch-crumb">' + CH.esc(group || 'ControlHub') + ' <span>' + CH.icon('chevron', 13) + '</span> <b>' + CH.esc(title) + '</b></div>'
          + '<div class="ch-omni-wrap"><span class="ch-omni-ico">' + CH.icon('sparkles', 17) + '</span>'
            + '<input id="ch-omni-input" class="ch-omni-input" placeholder="Ask or search ControlHub…  e.g. “show open exceptions”" autocomplete="off">'
            + '<span class="ch-omni-badge">AI</span>'
            + '<div class="ch-omni-panel" id="ch-omni-panel"><div class="ch-omni-scroll" id="ch-omni-scroll"></div></div></div>'
          + '<div class="ch-topbar-spacer"></div>'
          + '<button class="ch-iconbtn" id="ch-palette-btn" title="Command palette (Ctrl/⌘K)">' + CH.icon('command', 17) + '</button>'
          + '<button class="ch-iconbtn" id="ch-chat-btn" title="Ask ControlHub AI">' + CH.icon('sparkles', 17) + '</button>'
          + '<button class="ch-iconbtn" title="Notifications">' + CH.icon('bell', 17) + '</button>'
          + '<button class="ch-iconbtn" id="ch-theme-btn" title="Toggle theme"><span data-theme-ico>' + themeIco + '</span></button>'
          + '<select class="ch-role-select" id="ch-role" title="Acting role (RBAC)">' + roleOpts + '</select>'
          + '<div class="ch-avatar" title="Jordan Pierce · ' + CH.getRole() + '">JP</div>'
        + '</header>'
        + '<div class="ch-content">' + content + '</div>'
      + '</div>';

    // replace only the [data-shell] node so page-defined overlays/scripts survive
    shell.replaceWith(app);
    mountOverlays();
    wireShell();
  }

  function mountOverlays() {
    // Floating chat launcher (always-visible bottom-right button)
    var fab = document.createElement('button');
    fab.className = 'ch-fab';
    fab.id = 'ch-chat-fab';
    fab.title = 'Ask ControlHub AI — chat to navigate';
    fab.innerHTML = CH.icon('sparkles', 20) + '<span class="ch-fab-label">Ask AI</span><span class="ch-fab-dot"></span>';
    document.body.appendChild(fab);

    // Command palette
    var pal = document.createElement('div');
    pal.className = 'ch-palette-wrap';
    pal.id = 'ch-palette';
    pal.innerHTML =
      '<div class="ch-palette" role="dialog"><div class="ch-palette-input">' + CH.icon('search', 18)
        + '<input id="ch-pal-input" placeholder="Jump to a page or search a policy…" autocomplete="off"><span class="ch-kbd">esc</span></div>'
        + '<div class="ch-palette-list" id="ch-pal-list"></div></div>';
    document.body.appendChild(pal);
  }

  function wireShell() {
    document.getElementById('ch-theme-btn').addEventListener('click', CH.toggleTheme);
    document.getElementById('ch-role').addEventListener('change', function (e) { CH.setRole(e.target.value); });
    // ---- Omni ask-bar: blended AI ask + search with an inline answer surface ----
    function wireOmni() {
      var input = document.getElementById('ch-omni-input');
      var panel = document.getElementById('ch-omni-panel');
      var scroll = document.getElementById('ch-omni-scroll');
      if (!input) return;
      var activeIdx = -1;

      function chip(t) { return '<button class="ch-omni-chip" data-chip="' + CH.esc(t) + '">' + CH.esc(t) + '</button>'; }
      function foot(q) {
        return '<div class="ch-omni-foot"><span class="ch-kbd">↑↓</span><span>navigate</span>'
          + '<span class="ch-kbd">↵</span><span>go</span><span class="sp"></span>'
          + (q ? '<span class="ch-omni-link" data-seeall="1">See all results ' + CH.icon('chevron', 12) + '</span>' : '') + '</div>';
      }
      function renderEmpty() {
        scroll.innerHTML = '<div class="ch-omni-ai"><div class="lead"><span class="spark">' + CH.icon('sparkles', 17) + '</span>'
          + '<div class="txt"><b>Ask ControlHub</b><div class="ch-faint fs12" style="margin-top:2px">Ask a question or search — I’ll surface the data and take you straight there.</div></div></div></div>'
          + '<div class="ch-omni-sec-label">Try asking</div><div class="ch-omni-chips">' + CH.CHAT_SUGGESTIONS.map(chip).join('') + '</div>' + foot('');
        activeIdx = -1; wireRows();
      }
      function renderAnswer(q) {
        var A = CH.ask(q);
        var html = '<div class="ch-omni-ai"><div class="lead"><span class="spark">' + CH.icon('sparkles', 17) + '</span><div class="txt">' + A.answer + '</div></div>';
        if (A.primary) html += '<button class="ch-btn is-primary sm" style="margin-top:11px" data-go="' + A.primary.route + '">' + CH.esc(A.primary.label) + ' ' + CH.icon('chevron', 14) + '</button>';
        if (A.cards && A.cards.length) {
          html += '<div class="ch-omni-cards">';
          A.cards.forEach(function (c) {
            html += '<div class="ch-omni-card" data-go="' + c.route + '"><span class="ci">' + CH.icon(c.icon, 15) + '</span>'
              + '<div class="cbody"><div class="ctitle">' + CH.esc(c.title) + '</div><div class="csub">' + CH.esc(c.sub) + '</div></div>'
              + '<span class="ccta">' + CH.esc(c.cta) + '</span></div>';
          });
          html += '</div>';
        }
        html += '</div>';
        if (A.results && A.results.length) {
          html += '<div class="ch-omni-sec-label">Results</div>';
          A.results.forEach(function (it) {
            html += '<div class="ch-omni-res" data-go="' + it.route + '">' + CH.icon(it.icon || 'file', 15)
              + '<span class="rt">' + CH.esc(it.title) + '</span>'
              + (it.code ? '<span class="code">' + it.code + '</span>' : '')
              + '<span class="ch-faint fs12 nowrap">' + CH.esc(it.kind || '') + '</span></div>';
          });
        }
        if (A.suggestions && A.suggestions.length) {
          html += '<div class="ch-omni-sec-label">Did you mean</div><div class="ch-omni-chips">' + A.suggestions.map(chip).join('') + '</div>';
        }
        html += foot(q);
        scroll.innerHTML = html; activeIdx = -1; wireRows();
      }
      function wireRows() {
        scroll.querySelectorAll('[data-go]').forEach(function (el) { el.addEventListener('mousedown', function (e) { e.preventDefault(); CH.go(el.dataset.go); }); });
        scroll.querySelectorAll('[data-chip]').forEach(function (el) { el.addEventListener('mousedown', function (e) { e.preventDefault(); input.value = el.dataset.chip; render(); input.focus(); }); });
        scroll.querySelectorAll('[data-seeall]').forEach(function (el) { el.addEventListener('mousedown', function (e) { e.preventDefault(); CH.go('search.html?q=' + encodeURIComponent(input.value.trim())); }); });
      }
      function render() { var q = input.value.trim(); q ? renderAnswer(q) : renderEmpty(); }
      function open() { panel.classList.add('open'); render(); }
      function close() { panel.classList.remove('open'); }
      CH.openOmni = function () { open(); input.focus(); };
      CH.closeOmni = close;

      input.addEventListener('focus', open);
      input.addEventListener('input', function () { panel.classList.add('open'); render(); });
      input.addEventListener('blur', function () { setTimeout(close, 170); });
      input.addEventListener('keydown', function (e) {
        var rows = scroll.querySelectorAll('[data-go]');
        if (e.key === 'ArrowDown') { e.preventDefault(); activeIdx = Math.min(activeIdx + 1, rows.length - 1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); activeIdx = Math.max(activeIdx - 1, -1); }
        else if (e.key === 'Enter') {
          var q = input.value.trim();
          if (activeIdx >= 0 && rows[activeIdx]) { CH.go(rows[activeIdx].dataset.go); return; }
          if (rows.length && q) { CH.go(rows[0].dataset.go); return; }
          if (q) { CH.go('search.html?q=' + encodeURIComponent(q)); return; }
          return;
        }
        else if (e.key === 'Escape') { close(); input.blur(); return; }
        else return;
        rows.forEach(function (el, i) { el.classList.toggle('active', i === activeIdx); });
        if (rows[activeIdx]) rows[activeIdx].scrollIntoView({ block: 'nearest' });
      });
    }
    wireOmni();
    // The "Ask AI" affordances open the full ask/search page (not just focus the omni bar).
    document.getElementById('ch-chat-btn').addEventListener('click', function () { CH.go('search.html'); });
    document.getElementById('ch-chat-fab').addEventListener('click', function () { CH.go('search.html'); });

    // palette
    var palWrap = document.getElementById('ch-palette'), palInput = document.getElementById('ch-pal-input'), palList = document.getElementById('ch-pal-list');
    var palItems = [], palActive = 0;
    function palData() {
      var nav = [];
      CH.NAV.forEach(function (g) { g.items.filter(CH.canSee).forEach(function (it) { nav.push({ type: 'Page · ' + g.group, label: it.label, icon: it.icon, route: it.href }); }); });
      var docs = CH.DOCS.map(function (d) { return { type: 'Doc · ' + d.cat, label: d.id + ' — ' + d.title, icon: 'file', route: 'wsp-viewer.html?doc=' + d.id }; });
      return nav.concat(docs);
    }
    function palRender(q) {
      var all = palData(); var ql = q.toLowerCase();
      palItems = all.filter(function (i) { return i.label.toLowerCase().indexOf(ql) !== -1 || i.type.toLowerCase().indexOf(ql) !== -1; }).slice(0, 20);
      palActive = 0;
      palList.innerHTML = palItems.map(function (i, idx) {
        return '<div class="ch-palette-item' + (idx === 0 ? ' active' : '') + '" data-r="' + i.route + '">' + CH.icon(i.icon, 16) + '<span>' + CH.esc(i.label) + '</span><span class="sub">' + i.type + '</span></div>';
      }).join('') || '<div class="ch-empty">No matches</div>';
      palList.querySelectorAll('.ch-palette-item').forEach(function (el) { el.addEventListener('click', function () { CH.go(el.dataset.r); }); });
    }
    CH.openPalette = function () { palWrap.classList.add('open'); palInput.value = ''; palRender(''); palInput.focus(); };
    function closePalette() { palWrap.classList.remove('open'); }
    document.getElementById('ch-palette-btn').addEventListener('click', CH.openPalette);
    palInput.addEventListener('input', function () { palRender(palInput.value); });
    palInput.addEventListener('keydown', function (e) {
      var els = palList.querySelectorAll('.ch-palette-item');
      if (e.key === 'ArrowDown') { e.preventDefault(); palActive = Math.min(palActive + 1, els.length - 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); palActive = Math.max(palActive - 1, 0); }
      else if (e.key === 'Enter') { if (palItems[palActive]) CH.go(palItems[palActive].route); return; }
      else return;
      els.forEach(function (el, i) { el.classList.toggle('active', i === palActive); });
      if (els[palActive]) els[palActive].scrollIntoView({ block: 'nearest' });
    });
    palWrap.addEventListener('click', function (e) { if (e.target === palWrap) closePalette(); });

    document.addEventListener('keydown', function (e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); palWrap.classList.contains('open') ? closePalette() : CH.openPalette(); }
      if (e.key === 'Escape') { closePalette(); if (CH.closeOmni) CH.closeOmni(); document.querySelectorAll('.ch-overlay.open').forEach(function (o) { o.classList.remove('open'); }); }
    });
  }

  /* generic overlay open/close helpers for page-defined modals */
  CH.openModal = function (id) { var m = document.getElementById(id); if (m) m.classList.add('open'); };
  CH.closeModal = function (id) { var m = document.getElementById(id); if (m) m.classList.add ? m.classList.remove('open') : 0; };

  document.addEventListener('DOMContentLoaded', function () {
    // wire any standalone theme buttons (landing/login/403)
    document.querySelectorAll('[data-theme-btn]').forEach(function (b) { b.addEventListener('click', CH.toggleTheme); });
    // wire standalone autocomplete inputs by class
    if (!document.querySelector('[data-shell]')) {
      var ai = document.querySelector('.ch-ac-input'), ab = document.querySelector('.ch-ac');
      if (ai && ab) CH.attachAutocomplete(ai, ab);
    }
    buildShell();
    // fill declarative icon slots in page content: <span data-ico="coins"></span>
    document.querySelectorAll('[data-ico]').forEach(function (el) {
      el.innerHTML = CH.icon(el.getAttribute('data-ico'), parseInt(el.getAttribute('data-ico-size'), 10) || 18);
    });
    // click-to-close on page-defined overlays
    document.querySelectorAll('.ch-overlay').forEach(function (o) {
      o.addEventListener('click', function (e) { if (e.target === o) o.classList.remove('open'); });
    });
    document.querySelectorAll('[data-close-modal]').forEach(function (b) {
      b.addEventListener('click', function () { var o = b.closest('.ch-overlay'); if (o) o.classList.remove('open'); });
    });
    document.querySelectorAll('[data-open-modal]').forEach(function (b) {
      b.addEventListener('click', function () { CH.openModal(b.getAttribute('data-open-modal')); });
    });
  });
})();
