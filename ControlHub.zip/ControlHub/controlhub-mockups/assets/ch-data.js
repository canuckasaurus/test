/* ControlHub — shared prototype data
 * All content here is mock/sample data for the GUI draft.
 * Roles per spec: Standard, Supervision, Trader, HR, Admin.
 */
window.CH = window.CH || {};

/* ---- Roles ---------------------------------------------------------- */
CH.ROLES = ['Standard', 'Supervision', 'Trader', 'HR', 'Admin'];

/* ---- Navigation tree (grouped by Django "app" / phase) --------------
 * roles: who may see the item. Admin always sees everything.
 * Omit `roles` => visible to all roles.
 */
CH.NAV = [
  {
    group: 'Home',
    items: [
      { id: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: 'home' },
      { id: 'search', label: 'Search', href: 'search.html', icon: 'search' },
    ],
  },
  {
    group: 'Core · Identity',
    items: [
      { id: 'users', label: 'Users & Roles', href: 'users.html', icon: 'users', roles: ['Supervision', 'Admin'] },
      { id: 'rbac', label: 'Access Matrix', href: 'rbac.html', icon: 'shield', roles: ['Admin'] },
    ],
  },
  {
    group: 'Work · HR',
    items: [
      { id: 'todo', label: 'My To-Do', href: 'todo.html', icon: 'inbox', badge: '7' },
      { id: 'hr-mandates', label: 'Job Mandates', href: 'hr-mandates.html', icon: 'briefcase', roles: ['HR', 'Supervision', 'Admin'] },
      { id: 'hr-absence', label: 'Absences', href: 'hr-absence.html', icon: 'calendar' },
      { id: 'hierarchy', label: 'My Organization', href: 'hierarchy.html', icon: 'sitemap', roles: ['HR', 'Supervision', 'Admin'] },
    ],
  },
  {
    group: 'Committees · Projects',
    items: [
      { id: 'nbc', label: 'New Business Cttee', href: 'nbc.html', icon: 'gavel', badge: '3' },
      { id: 'kanban', label: 'Project Board', href: 'kanban.html', icon: 'columns' },
      { id: 'gantt', label: 'Program Gantt', href: 'gantt.html', icon: 'timeline' },
      { id: 'attestations', label: 'Attestations', href: 'attestations.html', icon: 'signature' },
    ],
  },
  {
    group: 'Trading Ops',
    items: [
      { id: 'pnl', label: 'P&L Attestations', href: 'pnl.html', icon: 'coins', roles: ['Trader', 'Supervision', 'Admin'] },
      { id: 'exceptions', label: 'Trade Exceptions', href: 'exceptions.html', icon: 'alert', roles: ['Trader', 'Supervision', 'Admin'], badge: '5' },
      { id: 'credit-limits', label: 'Credit Limits', href: 'credit-limits.html', icon: 'gauge', roles: ['Trader', 'Supervision', 'Admin'] },
    ],
  },
  {
    group: 'Governance',
    items: [
      { id: 'wsp', label: 'WSP Library', href: 'wsp.html', icon: 'book' },
      { id: 'osfi', label: 'OSFI Mapping', href: 'osfi.html', icon: 'scale', roles: ['Supervision', 'Admin'] },
      { id: 'atari', label: 'Algorithm Registry', href: 'atari.html', icon: 'cpu', roles: ['Supervision', 'Admin'] },
    ],
  },
  {
    group: 'Analytics',
    items: [
      { id: 'scorecard', label: 'Adherence Scorecard', href: 'scorecard.html', icon: 'chart' },
      { id: 'rollups', label: 'Hierarchy Roll-ups', href: 'rollups.html', icon: 'layers', roles: ['HR', 'Supervision', 'Admin'] },
    ],
  },
];

/* ---- Policy / procedure document index (search autocomplete) -------- */
CH.DOCS = [
  { id: 'WSP-001', title: 'Written Supervisory Procedures — Equities Desk', cat: 'WSP', owner: 'Supervision' },
  { id: 'WSP-014', title: 'Trade Exception Handling & Commentary Standard', cat: 'WSP', owner: 'Supervision' },
  { id: 'WSP-022', title: 'Order Handling & Best Execution Supervision', cat: 'WSP', owner: 'Supervision' },
  { id: 'POL-1100', title: 'Best Execution Policy', cat: 'Policy', owner: 'Compliance' },
  { id: 'POL-2200', title: 'Personal Account Dealing Policy', cat: 'Policy', owner: 'Compliance' },
  { id: 'POL-0900', title: 'Credit Limit Governance Policy', cat: 'Policy', owner: 'Risk' },
  { id: 'POL-0500', title: 'Absence & Leave Policy', cat: 'Policy', owner: 'HR' },
  { id: 'POL-6000', title: 'Role Attestation Policy (90-day cycle)', cat: 'Policy', owner: 'Governance' },
  { id: 'PRC-3100', title: 'New Business Approval Procedure (NBC)', cat: 'Procedure', owner: 'Governance' },
  { id: 'PRC-4500', title: 'End-of-Day P&L Sign-off Procedure', cat: 'Procedure', owner: 'Finance' },
  { id: 'PRC-7200', title: 'Algorithm Change Management Procedure (ATARI)', cat: 'Procedure', owner: 'Quant Governance' },
  { id: 'OSFI-B13', title: 'OSFI B-13 Technology & Cyber Risk — Control Mapping', cat: 'Regulatory', owner: 'Governance' },
  { id: 'OSFI-E23', title: 'OSFI E-23 Model Risk Management — Control Mapping', cat: 'Regulatory', owner: 'Governance' },
  { id: 'PRC-5500', title: 'Credit Limit Breach Escalation Procedure', cat: 'Procedure', owner: 'Risk' },
  { id: 'POL-8000', title: 'Records Retention & Immutability Policy', cat: 'Policy', owner: 'Governance' },
];

/* ---- Org roster & hierarchies --------------------------------------
 * One roster powers BOTH the HR reporting-line tree and the management
 * roll-ups. Each person carries their reporting manager (`mgr`) plus the
 * dimensions we can aggregate along (desk / dept / entity / region) and a
 * few GRC metrics so the tree doubles as a supervision tool.
 *   attest: 'current' | 'due' | 'overdue'   (role-attestation state)
 *   exc:    open trade exceptions owned      abs: pending absence requests
 *   score:  personal adherence score (0–100)
 * `CH.CURRENT_USER` is the acting user — the HR tree is rooted here, so a
 * manager only ever sees their own downward chain (Admin sees the whole org).
 */
CH.CURRENT_USER = 'jpierce';
CH.PEOPLE = [
  // id, name, initials, title, mgr, desk, dept, entity, region, score, attest, exc, abs
  { id:'mchen',     name:'Margaret Chen',  init:'MC', title:'CEO · Global Markets',            mgr:null,       desk:'—',           dept:'Executive',        entity:'CH Capital Markets Inc.', region:'North America', score:97, attest:'current', exc:0, abs:0 },
  { id:'jpierce',   name:'Jordan Pierce',  init:'JP', title:'COO · Global Markets',            mgr:'mchen',    desk:'—',           dept:'Executive',        entity:'CH Capital Markets Inc.', region:'North America', score:92, attest:'due',     exc:0, abs:0 },

  { id:'evasquez',  name:'Elena Vasquez',  init:'EV', title:'Head of Rates',                   mgr:'jpierce',  desk:'Rates',       dept:'Front Office',     entity:'CH Capital Markets Inc.', region:'North America', score:90, attest:'current', exc:1, abs:0 },
  { id:'dkrause',   name:'Devon Krause',   init:'DK', title:'Head of FX',                      mgr:'jpierce',  desk:'FX',          dept:'Front Office',     entity:'CH Securities LLC',       region:'North America', score:88, attest:'due',     exc:2, abs:1 },
  { id:'sricci',    name:'Sofia Ricci',    init:'SR', title:'Head of Equity Derivatives',      mgr:'jpierce',  desk:'Equities',    dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:93, attest:'current', exc:0, abs:0 },
  { id:'tnkemelu',  name:'Theo Nkemelu',   init:'TN', title:'Head of Commodities',             mgr:'jpierce',  desk:'Commodities', dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:85, attest:'overdue', exc:1, abs:0 },
  { id:'mokafor',   name:'Musa Okafor',    init:'MO', title:'Head of Market & Counterparty Risk', mgr:'jpierce', desk:'—',        dept:'Risk',             entity:'CH Capital Markets Inc.', region:'North America', score:94, attest:'current', exc:0, abs:1 },
  { id:'alund',     name:'Aisha Lund',     init:'AL', title:'Head of Supervision & Compliance',mgr:'jpierce',  desk:'—',           dept:'Compliance',       entity:'CH International Ltd.',    region:'EMEA',          score:96, attest:'current', exc:0, abs:0 },
  { id:'pjain',     name:'Priya Jain',     init:'PJ', title:'Head of Quant Governance',        mgr:'jpierce',  desk:'—',           dept:'Quant Governance', entity:'CH Asia Pacific Pte.',    region:'APAC',          score:91, attest:'due',     exc:0, abs:0 },
  { id:'rbhatt',    name:'Rani Bhatt',     init:'RB', title:'HR Business Partner Lead',        mgr:'jpierce',  desk:'—',           dept:'Human Resources',  entity:'CH Capital Markets Inc.', region:'North America', score:95, attest:'current', exc:0, abs:0 },

  { id:'kwatanabe', name:'Kenji Watanabe', init:'KW', title:'VP · Rates Trader',               mgr:'evasquez', desk:'Rates',       dept:'Front Office',     entity:'CH Asia Pacific Pte.',    region:'APAC',          score:78, attest:'overdue', exc:2, abs:0 },
  { id:'lvogt',     name:'Lena Vogt',      init:'LV', title:'Rates Trader',                    mgr:'evasquez', desk:'Rates',       dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:86, attest:'current', exc:0, abs:1 },
  { id:'ohaddad',   name:'Omar Haddad',    init:'OH', title:'Rates Strategist',               mgr:'evasquez', desk:'Rates',       dept:'Front Office',     entity:'CH Capital Markets Inc.', region:'North America', score:90, attest:'current', exc:0, abs:0 },

  { id:'nsorensen', name:'Nina Sørensen',  init:'NS', title:'FX Options Market Maker',         mgr:'dkrause',  desk:'FX',          dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:72, attest:'overdue', exc:3, abs:0 },
  { id:'cduarte',   name:'Carlos Duarte',  init:'CD', title:'FX Spot Trader',                  mgr:'dkrause',  desk:'FX',          dept:'Front Office',     entity:'CH Securities LLC',       region:'North America', score:84, attest:'due',     exc:1, abs:0 },

  { id:'gkim',      name:'Grace Kim',      init:'GK', title:'Equity Derivatives Trader',       mgr:'sricci',   desk:'Equities',    dept:'Front Office',     entity:'CH Securities LLC',       region:'North America', score:91, attest:'current', exc:0, abs:0 },
  { id:'tfletcher', name:'Tom Fletcher',   init:'TF', title:'Delta One Trader',                mgr:'sricci',   desk:'Equities',    dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:88, attest:'due',     exc:1, abs:0 },

  { id:'ytanaka',   name:'Yuki Tanaka',    init:'YT', title:'Energy Structurer',               mgr:'tnkemelu', desk:'Commodities', dept:'Front Office',     entity:'CH Asia Pacific Pte.',    region:'APAC',          score:83, attest:'current', exc:0, abs:1 },
  { id:'portiz',    name:'Pablo Ortiz',    init:'PO', title:'Metals Trader',                   mgr:'tnkemelu', desk:'Commodities', dept:'Front Office',     entity:'CH International Ltd.',    region:'EMEA',          score:74, attest:'overdue', exc:1, abs:0 },

  { id:'ibauer',    name:'Ingrid Bauer',   init:'IB', title:'Credit Risk Analyst',             mgr:'mokafor',  desk:'—',           dept:'Risk',             entity:'CH Capital Markets Inc.', region:'North America', score:92, attest:'current', exc:0, abs:0 },
  { id:'sreyes',    name:'Sam Reyes',      init:'SA', title:'Market Risk Analyst',             mgr:'mokafor',  desk:'—',           dept:'Risk',             entity:'CH Securities LLC',       region:'North America', score:89, attest:'due',     exc:0, abs:0 },

  { id:'dlevi',     name:'Dana Levi',      init:'DL', title:'Surveillance Officer',            mgr:'alund',    desk:'—',           dept:'Compliance',       entity:'CH International Ltd.',    region:'EMEA',          score:95, attest:'current', exc:0, abs:0 },
  { id:'vhugo',     name:'Victor Hugo',    init:'VH', title:'Supervision Analyst',             mgr:'alund',    desk:'—',           dept:'Compliance',       entity:'CH Capital Markets Inc.', region:'North America', score:90, attest:'due',     exc:0, abs:1 },

  { id:'wchen',     name:'Wei Chen',       init:'WC', title:'Quant Developer · ATARI',         mgr:'pjain',    desk:'—',           dept:'Quant Governance', entity:'CH Asia Pacific Pte.',    region:'APAC',          score:87, attest:'current', exc:0, abs:0 },
  { id:'arao',      name:'Aditi Rao',      init:'AR', title:'Model Validation Lead',           mgr:'pjain',    desk:'—',           dept:'Quant Governance', entity:'CH International Ltd.',    region:'EMEA',          score:93, attest:'current', exc:0, abs:0 },

  { id:'bcohen',    name:'Beth Cohen',     init:'BC', title:'HR Analyst',                      mgr:'rbhatt',   desk:'—',           dept:'Human Resources',  entity:'CH Capital Markets Inc.', region:'North America', score:94, attest:'current', exc:0, abs:0 },
];

/* Dimensions the management roll-up can aggregate along ("custom hierarchies") */
CH.HIER_DIMS = [
  { id:'desk',   label:'Trading Desk',  field:'desk',   icon:'coins',    empty:'Control functions' },
  { id:'dept',   label:'Department',    field:'dept',   icon:'building',  empty:'Unassigned' },
  { id:'entity', label:'Legal Entity',  field:'entity', icon:'scale',    empty:'Unassigned' },
  { id:'region', label:'Region',        field:'region', icon:'home',     empty:'Unassigned' },
];

/* Roster helpers (pure, no side effects) */
CH.byId        = function (id) { for (var i=0;i<CH.PEOPLE.length;i++) if (CH.PEOPLE[i].id===id) return CH.PEOPLE[i]; return null; };
CH.reportsOf   = function (id) { return CH.PEOPLE.filter(function (p) { return p.mgr === id; }); };
CH.chainUnder  = function (id) { var out=[]; (function rec(m){ CH.reportsOf(m).forEach(function(c){ out.push(c); rec(c.id); }); })(id); return out; };
CH.managerChain= function (id) { var out=[], p=CH.byId(id); while (p && p.mgr) { var m=CH.byId(p.mgr); if(!m) break; out.push(m); p=m; } return out.reverse(); };

/* Aggregate a set of people by a dimension field → summary rows.
 * people defaults to the full roster; pass CH.chainUnder(id) to scope it. */
CH.aggregateBy = function (field, people) {
  people = people || CH.PEOPLE;
  var g = {};
  people.forEach(function (p) { var k = p[field] || '—'; (g[k] = g[k] || []).push(p); });
  return Object.keys(g).map(function (k) {
    var a = g[k];
    var sum = a.reduce(function (s, p) { return s + p.score; }, 0);
    return {
      key: k, people: a, count: a.length,
      avgScore: Math.round(sum / a.length),
      overdue:  a.filter(function (p) { return p.attest === 'overdue'; }).length,
      dueSoon:  a.filter(function (p) { return p.attest === 'due'; }).length,
      exceptions: a.reduce(function (s, p) { return s + p.exc; }, 0),
      absences:   a.reduce(function (s, p) { return s + p.abs; }, 0),
    };
  }).sort(function (x, y) { return y.avgScore - x.avgScore; });
};

/* ---- Dashboard scope + widget catalog -------------------------------
 * The customizable dashboard can be scoped to an individual (you), a
 * hand-picked list of individuals, or your team drilled 1..n levels down
 * the reporting line. Widgets flagged `scoped` recompute for that set.
 */
CH.chainToDepth = function (id, depth) {
  var out = [];
  (function rec(m, lvl) { if (lvl > depth) return; CH.reportsOf(m).forEach(function (c) { out.push({ person: c, level: lvl }); rec(c.id, lvl + 1); }); })(id, 1);
  return out;
};
CH.maxDepth = function (id) {
  var d = 0;
  (function rec(m, lvl) { var r = CH.reportsOf(m); if (r.length) { d = Math.max(d, lvl); r.forEach(function (c) { rec(c.id, lvl + 1); }); } })(id, 1);
  return d;
};
CH.scopePeople = function (scope) {
  var me = CH.byId(CH.CURRENT_USER);
  if (!scope || scope.mode === 'individual') return me ? [me] : [];
  if (scope.mode === 'people') return (scope.people || []).map(CH.byId).filter(Boolean);
  return CH.chainToDepth(CH.CURRENT_USER, scope.depth || 1).map(function (x) { return x.person; }); // team
};
CH.scopeStats = function (people) {
  people = people || [];
  if (!people.length) return { count: 0, avgScore: 0, overdue: 0, dueSoon: 0, exceptions: 0, absences: 0 };
  return {
    count: people.length,
    avgScore: Math.round(people.reduce(function (s, p) { return s + p.score; }, 0) / people.length),
    overdue: people.filter(function (p) { return p.attest === 'overdue'; }).length,
    dueSoon: people.filter(function (p) { return p.attest === 'due'; }).length,
    exceptions: people.reduce(function (s, p) { return s + p.exc; }, 0),
    absences: people.reduce(function (s, p) { return s + p.abs; }, 0),
  };
};

/* Catalog of dashboard widgets (metadata; dashboard.html renders each).
 * span: desktop column span (1 or 2). scoped: recomputes with the scope. */
CH.WIDGETS = [
  { id: 'adherence',             title: 'Adherence score',     section: 'Analytics',   icon: 'chart',     span: 1, scoped: true,  desc: 'Weighted adherence for the current scope' },
  { id: 'my-tasks',              title: 'To-Do',               section: 'Work · HR',   icon: 'inbox',     span: 1, scoped: true,  desc: 'Open tasks in scope' },
  { id: 'trade-exceptions',      title: 'Trade exceptions',    section: 'Trading Ops', icon: 'alert',     span: 1, scoped: true,  desc: 'Open exceptions & commentary status' },
  { id: 'attestations-due',      title: 'Attestations',        section: 'Governance',  icon: 'signature', span: 1, scoped: true,  desc: 'Attestation status for the scope' },
  { id: 'credit-alerts',         title: 'Credit limits',       section: 'Trading Ops', icon: 'gauge',     span: 1, scoped: false, desc: 'Utilization & breach alerts' },
  { id: 'pnl-signoff',           title: 'P&L sign-off',        section: 'Trading Ops', icon: 'coins',     span: 1, scoped: false, desc: 'End-of-day desk attestation status' },
  { id: 'nbc-queue',             title: 'NBC proposals',       section: 'Committees',  icon: 'gavel',     span: 1, scoped: false, desc: 'New Business Committee by state' },
  { id: 'absences',              title: 'Pending absences',    section: 'Work · HR',   icon: 'calendar',  span: 1, scoped: true,  desc: 'Leave requests awaiting approval' },
  { id: 'mandates',              title: 'Job mandates',        section: 'Work · HR',   icon: 'briefcase', span: 1, scoped: false, desc: 'Open hiring mandates' },
  { id: 'kanban-summary',        title: 'Project board',       section: 'Committees',  icon: 'columns',   span: 1, scoped: false, desc: 'Projects by column' },
  { id: 'atari-changes',         title: 'Algo changes',        section: 'Governance',  icon: 'cpu',       span: 1, scoped: false, desc: 'Recent ATARI parameter changes' },
  { id: 'osfi-coverage',         title: 'OSFI coverage',       section: 'Governance',  icon: 'scale',     span: 1, scoped: false, desc: 'B-13 / E-23 control coverage' },
  { id: 'team-roster',           title: 'Team roster & GRC',   section: 'People',      icon: 'users',     span: 2, scoped: true,  desc: 'People in scope with GRC status' },
  { id: 'team-adherence',        title: 'Adherence by person', section: 'People',      icon: 'sitemap',   span: 1, scoped: true,  desc: 'Adherence bars across the scope' },
  { id: 'scorecard-leaderboard', title: 'Desk leaderboard',    section: 'Analytics',   icon: 'chart',     span: 2, scoped: false, desc: 'Desks ranked by adherence' },
  { id: 'activity',              title: 'Recent activity',     section: 'Home',        icon: 'clock',     span: 1, scoped: false, desc: 'Latest events across the platform' },
];
CH.WIDGET_DEFAULT = ['adherence', 'my-tasks', 'trade-exceptions', 'attestations-due', 'team-roster', 'credit-alerts', 'nbc-queue', 'activity'];

/* ---- Universal search index ("Google-style" dedicated search) -------
 * One flat, weighted index over everything a user might want to reach, so
 * the dedicated search page can fan results into sections and let the user
 * filter down until a single "path to take" (route) remains:
 *   - Smart actions : curated deep-links straight to a filtered screen
 *   - Pages         : nav modules (RBAC-aware via CH.canSee)
 *   - Policies      : CH.DOCS  ·  People : CH.PEOPLE  ·  Records : samples
 */
CH.SEARCH_SECTIONS = [
  { id:'action', label:'Smart actions',         icon:'sparkles', blurb:'jump straight to a filtered view' },
  { id:'page',   label:'Pages & modules',       icon:'command',  blurb:'open a screen' },
  { id:'policy', label:'Policies & procedures',  icon:'book',     blurb:'WSPs, policies, procedures, regulatory' },
  { id:'person', label:'People',                icon:'users',    blurb:'the org roster' },
  { id:'record', label:'Records',               icon:'file',     blurb:'exceptions, proposals, algos, tasks' },
];

/* Curated "smart action" paths — a saved search that lands on a filtered screen */
CH.QUICKPATHS = [
  { label:'Trade exceptions needing commentary', desc:'Open, uncommented exceptions to clear', route:'exceptions.html?status=open',  cat:'Trading Ops', icon:'alert',     kw:'clear commentary late cancel amend uncommented' },
  { label:'NBC proposals in Risk Review',        desc:'New Business Committee queue, Risk Review', route:'nbc.html?status=risk_review', cat:'Committees', icon:'gavel',     kw:'new business committee risk review pending' },
  { label:'Today’s P&L attestations',            desc:'End-of-day desk sign-offs',            route:'pnl.html',                    cat:'Trading Ops', icon:'coins',     kw:'pnl profit loss sign off eod end of day' },
  { label:'Credit limits over 90%',              desc:'Utilization breaches & escalation',    route:'credit-limits.html',          cat:'Trading Ops', icon:'gauge',     kw:'credit limit breach utilization escalation' },
  { label:'My overdue attestations',             desc:'Role attestations past the 90-day cycle', route:'attestations.html',        cat:'Governance',  icon:'signature', kw:'attest overdue 90 day sign policy' },
  { label:'Roll up adherence by trading desk',   desc:'Aggregate GRC posture by desk',        route:'rollups.html?by=desk',        cat:'Analytics',   icon:'layers',    kw:'aggregate hierarchy desk rollup roll-up breakdown' },
  { label:'My reporting line',                   desc:'Org hierarchy with team GRC status',   route:'hierarchy.html',              cat:'People',      icon:'sitemap',   kw:'org organization team reports hierarchy chain manager' },
  { label:'Pending absence approvals',           desc:'Leave requests awaiting sign-off',     route:'hr-absence.html?status=pending', cat:'HR',       icon:'calendar',  kw:'absence leave vacation approve pending' },
  { label:'Overdue to-do items',                 desc:'Aggregated tasks past due',            route:'todo.html?status=overdue',    cat:'Work',        icon:'inbox',     kw:'todo task overdue due inbox' },
  { label:'ATARI algorithm registry',            desc:'Registered algos & immutable history', route:'atari.html',                  cat:'Governance',  icon:'cpu',       kw:'algorithm atari registry algo change history' },
  { label:'OSFI B-13 / E-23 control mapping',    desc:'Regulatory control coverage & gaps',   route:'osfi.html',                   cat:'Governance',  icon:'scale',     kw:'osfi regulatory b13 e23 control mapping auditor' },
  { label:'Adherence scorecard',                 desc:'Weighted policy-adherence score',      route:'scorecard.html',              cat:'Analytics',   icon:'chart',     kw:'adherence score scorecard ranking band' },
];

/* Sample cross-domain records (normally rows inside each module) */
CH.RECORDS = [
  { id:'LT-4471',   title:'Late trade LT-4471 · UST 10Y Future',     type:'Trade Exception', cat:'Trading Ops', icon:'alert',     route:'exception-clear.html?id=LT-4471',  kw:'late uncommented rates clear commentary' },
  { id:'EX-8841',   title:'Exception EX-8841 · amended · cleared',   type:'Trade Exception', cat:'Trading Ops', icon:'alert',     route:'exceptions.html',                  kw:'amended cleared equities' },
  { id:'NBC-2231',  title:'Structured Note · Risk Review',           type:'NBC Proposal',    cat:'Committees',  icon:'gavel',     route:'nbc-detail.html?id=NBC-2231',      kw:'new business structured products risk review' },
  { id:'NBC-2234',  title:'FX Accumulator Program · Risk Review',    type:'NBC Proposal',    cat:'Committees',  icon:'gavel',     route:'nbc-detail.html?id=NBC-2234',      kw:'fx exotic option risk review' },
  { id:'ALGO-0142', title:'VWAP Sweeper · v3.4 · Live',              type:'Algorithm',       cat:'Governance',  icon:'cpu',       route:'atari-history.html?id=ALGO-0142',  kw:'vwap equities live algo change history immutable' },
  { id:'ALGO-0155', title:'TWAP Rates · Live',                       type:'Algorithm',       cat:'Governance',  icon:'cpu',       route:'atari-history.html?id=ALGO-0155',  kw:'twap rates algo live' },
  { id:'MND-2041',  title:'Senior Rates Trader · job mandate',       type:'Job Mandate',     cat:'HR',          icon:'briefcase', route:'hr-mandates.html',                 kw:'hiring rates front office mandate posted' },
  { id:'PNL-0718',  title:'Sign EOD P&L — Rates Desk',              type:'Task',            cat:'Trading Ops', icon:'inbox',     route:'task-detail.html?id=PNL-0718',     kw:'todo sign pnl eod rates desk due today' },
  { id:'ABS-1187',  title:'Absence approval — M. Okafor',            type:'Task',            cat:'HR',          icon:'calendar',  route:'task-detail.html?id=ABS-1187',     kw:'absence leave approve okafor pending' },
  { id:'FX',        title:'FX desk · credit utilization 91%',        type:'Credit Limit',    cat:'Trading Ops', icon:'gauge',     route:'credit-limits.html',               kw:'fx credit limit breach 91 utilization escalation' },
];

/* Build the flat, weighted index (RBAC-aware for pages) */
CH.searchIndex = function () {
  var idx = [];
  (CH.QUICKPATHS || []).forEach(function (q) {
    idx.push({ section:'action', kind:'Smart action', title:q.label, sub:q.desc, refine:q.cat, icon:q.icon, route:q.route,
      kw:(q.label + ' ' + q.desc + ' ' + q.kw + ' ' + q.cat).toLowerCase() });
  });
  CH.NAV.forEach(function (g) {
    g.items.filter(function (it) { return CH.canSee ? CH.canSee(it) : true; }).forEach(function (it) {
      idx.push({ section:'page', kind:'Module', title:it.label, sub:g.group, refine:g.group, icon:it.icon, route:it.href,
        kw:(it.label + ' ' + g.group).toLowerCase() });
    });
  });
  CH.DOCS.forEach(function (d) {
    idx.push({ section:'policy', kind:d.cat, title:d.title, sub:d.id + ' · ' + d.owner, refine:d.cat, code:d.id, icon:'file',
      route:'wsp-viewer.html?doc=' + d.id, kw:(d.id + ' ' + d.title + ' ' + d.cat + ' ' + d.owner).toLowerCase() });
  });
  (CH.PEOPLE || []).forEach(function (p) {
    idx.push({ section:'person', kind:'Person', title:p.name, sub:p.title + ' · ' + (p.desk !== '—' ? p.desk : p.dept),
      refine:p.dept, init:p.init, icon:'users', route:'hierarchy.html',
      kw:(p.name + ' ' + p.title + ' ' + p.desk + ' ' + p.dept + ' ' + p.region + ' ' + p.entity).toLowerCase() });
  });
  (CH.RECORDS || []).forEach(function (r) {
    idx.push({ section:'record', kind:r.type, title:r.title, sub:r.type + ' · ' + r.id, refine:r.type, code:r.id, icon:r.icon,
      route:r.route, kw:(r.id + ' ' + r.title + ' ' + r.type + ' ' + r.kw + ' ' + r.cat).toLowerCase() });
  });
  return idx;
};

/* Weighted AND-search. Returns [{item, score}] sorted best-first.
 * Empty query returns everything (score 0) so a section can be "browsed". */
CH.search = function (q, section) {
  var all = CH.searchIndex();
  if (section && section !== 'all') all = all.filter(function (i) { return i.section === section; });
  var ql = (q || '').toLowerCase().trim();
  if (!ql) return all.map(function (i) { return { item:i, score:0 }; });
  var terms = ql.split(/\s+/);
  return all.map(function (i) {
    var code = (i.code || '').toLowerCase();
    var hay = (i.title + ' ' + i.sub + ' ' + code + ' ' + i.kw).toLowerCase();
    if (!terms.every(function (t) { return hay.indexOf(t) !== -1; })) return { item:i, score:0 };
    var s = 0;
    terms.forEach(function (t) {
      if (code === t) s += 12;
      else if (code.indexOf(t) !== -1) s += 6;
      if (i.title.toLowerCase().indexOf(t) !== -1) s += 4;
      if (i.sub.toLowerCase().indexOf(t) !== -1) s += 2;
      s += 1;
    });
    if (i.section === 'action') s += 2; // gently surface curated paths
    return { item:i, score:s };
  }).filter(function (r) { return r.score > 0; }).sort(function (a, b) { return b.score - a.score; });
};

/* ---- Answer engine for the omni ask-bar -----------------------------
 * Turns a free-text query into a structured, actionable answer: a spoken
 * reply, a primary "go" action, actionable result cards pulled from LIVE
 * mock data, blended search results, and follow-up suggestions. This is
 * what makes the ask-bar feel like it understands the platform.
 */
CH.ask = function (q) {
  var ql = (q || '').toLowerCase().trim();
  var A = { query: q, answer: '', primary: null, cards: [], suggestions: [], results: [] };
  function card(icon, title, sub, route, cta) { return { icon: icon, title: title, sub: sub, route: route, cta: cta || 'Open' }; }

  var overdue = (CH.PEOPLE || []).filter(function (p) { return p.attest === 'overdue'; });

  if (/exception|commentary|cancel|amend|late trade|uncommented/.test(ql)) {
    A.answer = '<b>5 open trade exceptions</b> — 3 still need written commentary before they can be cleared (WSP-014).';
    A.primary = { label: 'Open exceptions queue', route: 'exceptions.html?status=open' };
    A.cards = [
      card('alert', 'LT-4471 · UST 10Y Future', 'Late · Rates · commentary required', 'exception-clear.html?id=LT-4471', 'Clear'),
      card('alert', 'Trade Exceptions', '5 open · 3 uncommented · 2 aging >24h', 'exceptions.html?status=open', 'Open'),
    ];
    A.suggestions = ['P&L attestations', 'credit limits over 90%'];
  } else if (/attest|overdue|90.?day|sign policy|lapsed/.test(ql)) {
    A.answer = '<b>' + overdue.length + ' overdue attestations</b> across your org — including your own POL-6000 role attestation, lapsed 4 days ago.';
    A.primary = { label: 'Open my attestations', route: 'attestations.html' };
    A.cards = [card('signature', 'POL-6000 · Role Attestation', 'You · lapsed 4 days ago', 'attestations.html', 'Sign')]
      .concat(overdue.slice(0, 3).map(function (p) { return card('users', p.name + ' · ' + p.title, (p.desk !== '—' ? p.desk : p.dept) + ' · attestation overdue', 'hierarchy.html', 'View'); }));
    A.suggestions = ['roll up adherence by desk', 'my reporting line'];
  } else if (/credit|limit|utili|breach|exposure/.test(ql)) {
    A.answer = '<b>FX desk at 91% credit utilization</b> — over the 90% threshold; escalation triggered per PRC-5500.';
    A.primary = { label: 'Open credit limits', route: 'credit-limits.html' };
    A.cards = [card('gauge', 'FX desk · 91% utilization', 'Breach · escalation active', 'credit-limits.html', 'View')];
    A.suggestions = ['open trade exceptions', 'P&L attestations'];
  } else if (/risk review|new business|\bnbc\b|committee|proposal/.test(ql)) {
    A.answer = '<b>3 NBC proposals in Risk Review</b> awaiting sign-off, including NBC-2231 Structured Note.';
    A.primary = { label: 'Open NBC · Risk Review', route: 'nbc.html?status=risk_review' };
    A.cards = [
      card('gavel', 'NBC-2231 · Structured Note', 'Risk Review · Structured Products', 'nbc-detail.html?id=NBC-2231', 'Open'),
      card('gavel', 'NBC-2234 · FX Accumulator', 'Risk Review · FX', 'nbc-detail.html?id=NBC-2234', 'Open'),
    ];
    A.suggestions = ['my to-do', 'roll up by desk'];
  } else if (/p ?& ?l|pnl|sign.?off|end of day|eod/.test(ql)) {
    A.answer = '<b>4 of 6 desks signed off</b> on end-of-day P&L. Your Rates desk sign-off is still pending.';
    A.primary = { label: 'Open P&L attestations', route: 'pnl.html' };
    A.cards = [card('coins', 'Rates · Govt Bonds', 'Pending your sign-off · cut-off 5:00pm', 'pnl.html', 'Sign')];
    A.suggestions = ['trade exceptions', 'credit limits'];
  } else if (/roll.?up|aggregat|by desk|by department|by entity|by region|breakdown/.test(ql)) {
    A.answer = 'Aggregating GRC posture by <b>trading desk</b>. Commodities is the lowest-scoring desk (81); Control functions the highest (93).';
    A.primary = { label: 'Open roll-ups by desk', route: 'rollups.html?by=desk' };
    A.cards = [card('layers', 'Roll-up by Trading Desk', '5 desks · firm avg 89', 'rollups.html?by=desk', 'Open')];
    A.suggestions = ['my reporting line', 'adherence scorecard'];
  } else if (/my org|organi|reporting|\bteam\b|my report|hierarch|who reports|direct report/.test(ql)) {
    A.answer = 'Your reporting line has <b>24 people across 3 levels</b>; ' + overdue.length + ' have overdue attestations.';
    A.primary = { label: 'Open my organization', route: 'hierarchy.html' };
    A.cards = [card('sitemap', 'My Organization', '24 in your chain · team avg 88', 'hierarchy.html', 'Open')];
    A.suggestions = ['roll up by desk', 'pending absence approvals'];
  } else if (/absence|leave|vacation|time off/.test(ql)) {
    A.answer = '<b>4 absence requests pending</b> approval, 2 routed to you.';
    A.primary = { label: 'Open absence tracking', route: 'hr-absence.html?status=pending' };
    A.cards = [card('calendar', 'Absence approvals', '4 pending · 2 need your sign-off', 'hr-absence.html?status=pending', 'Review')];
    A.suggestions = ['my to-do', 'job mandates'];
  } else if (/scorecard|adherence|my score|ranking/.test(ql)) {
    A.answer = 'Your adherence score is <b>92 (Strong)</b>, rank 14/210. Attestations are the main drag (88).';
    A.primary = { label: 'Open adherence scorecard', route: 'scorecard.html' };
    A.cards = [card('chart', 'Adherence Scorecard', 'You 92 · firm avg 86', 'scorecard.html', 'Open')];
    A.suggestions = ['my overdue attestations', 'roll up by desk'];
  }

  // Person lookup (only if nothing more specific matched)
  if (!A.primary && ql.length >= 3) {
    var person = (CH.PEOPLE || []).filter(function (p) { return p.name.toLowerCase().indexOf(ql) !== -1; })[0];
    if (person) {
      A.answer = 'Found <b>' + person.name + '</b> — ' + person.title + '.';
      A.primary = { label: 'View ' + person.name + ' in org', route: 'hierarchy.html' };
      A.cards = [card('users', person.name + ' · ' + person.title, (person.desk !== '—' ? person.desk : person.dept) + ' · adherence ' + person.score, 'hierarchy.html', 'View')];
      A.suggestions = ['my reporting line', 'roll up by department'];
    }
  }

  A.results = CH.search(q).slice(0, 5).map(function (r) { return r.item; });

  if (!A.primary) {
    var intent = CH.resolveIntent(q);
    if (intent) { A.answer = intent.say; A.primary = { label: 'Go there', route: intent.route }; }
    else if (A.results.length) { A.answer = 'Here are the closest matches across ControlHub — pick one to go there.'; }
    else { A.answer = "I can navigate you anywhere and surface exceptions, attestations, people, policies and more. Try “open trade exceptions” or a code like “LT-4471”."; }
  }
  if (!A.suggestions.length) A.suggestions = ['open trade exceptions', 'my overdue attestations', 'roll up by desk'];
  return A;
};

/* ---- Chat "intent → route" map (mock Agentic Router) ----------------
 * Reproduces the spec's chat-to-navigate: an utterance resolves to a
 * route (and optional pre-applied filter), like an HX-Redirect payload.
 */
CH.INTENTS = [
  { rx: /(roll.?up|aggregat|by desk|by department|by division|by entity|by region|breakdown by|desk view)/i, route: 'rollups.html', say: 'Opening the <b>Hierarchy Roll-ups</b> — aggregate by desk, department, entity or region.' },
  { rx: /(my org|organi[sz]ation|reporting line|reporting chain|my team|my report|direct report|who reports|org chart|hierarch)/i, route: 'hierarchy.html', say: 'Opening <b>My Organization</b> — your full reporting line with per-person GRC status.' },
  { rx: /(risk review|pending risk|awaiting risk)/i, route: 'nbc.html?status=risk_review', say: 'Opening New Business Committee proposals filtered to <b>Risk Review</b>.' },
  { rx: /(new business|nbc|committee|proposal)/i, route: 'nbc.html', say: 'Taking you to the <b>New Business Committee</b> queue.' },
  { rx: /(to-?do|my task|my work|inbox)/i, route: 'todo.html', say: 'Here is your <b>Universal To-Do</b> inbox.' },
  { rx: /(p ?& ?l|pnl|end of day|sign.?off)/i, route: 'pnl.html', say: 'Opening today’s <b>P&L Attestations</b>.' },
  { rx: /(exception|cancel|amend|late trade)/i, route: 'exceptions.html?status=open', say: 'Showing open <b>Trade Exceptions</b> needing commentary.' },
  { rx: /(credit|limit|utili[sz]ation|breach)/i, route: 'credit-limits.html', say: 'Opening <b>Credit Limit</b> monitoring.' },
  { rx: /(scorecard|adherence|score|ranking)/i, route: 'scorecard.html', say: 'Loading the <b>Adherence Scorecard</b>.' },
  { rx: /(algorithm|atari|registry|algo)/i, route: 'atari.html', say: 'Opening the <b>ATARI Algorithm Registry</b>.' },
  { rx: /(osfi|b-?13|e-?23|regulat)/i, route: 'osfi.html', say: 'Opening the <b>OSFI Control Mapping</b>.' },
  { rx: /(absence|leave|vacation|time off)/i, route: 'hr-absence.html', say: 'Opening <b>Absence Tracking</b>.' },
  { rx: /(mandate|job description|role profile)/i, route: 'hr-mandates.html', say: 'Opening <b>Job Mandates</b>.' },
  { rx: /(attest|90.?day|sign policy)/i, route: 'attestations.html', say: 'Opening your <b>Role Attestations</b>.' },
  { rx: /(wsp|policy|procedure|document|library)/i, route: 'wsp.html', say: 'Opening the <b>WSP / Policy Library</b>.' },
  { rx: /(kanban|board|workflow)/i, route: 'kanban.html', say: 'Opening the <b>Project Board</b>.' },
  { rx: /(gantt|program|timeline|schedule)/i, route: 'gantt.html', say: 'Opening the <b>Program Gantt</b>.' },
  { rx: /(user|permission|access|rbac)/i, route: 'rbac.html', say: 'Opening the <b>Access Control Matrix</b>.' },
  { rx: /(search everything|universal search|search for|search across|look up|find anything)/i, route: 'search.html', say: 'Opening <b>universal search</b> — filter across modules, policies, people and records.' },
];

/* Resolve an utterance to an intent (returns null if no confident match) */
CH.resolveIntent = function (text) {
  if (!text || !text.trim()) return null;
  for (var i = 0; i < CH.INTENTS.length; i++) {
    if (CH.INTENTS[i].rx.test(text)) return CH.INTENTS[i];
  }
  return null;
};

/* Example prompts surfaced in the chat UI */
CH.CHAT_SUGGESTIONS = [
  'Take me to NBC proposals pending risk review',
  'Show open trade exceptions needing commentary',
  "Open today's P&L attestations",
  'Where do I sign my role attestation?',
  'Show my reporting line and team GRC status',
  'Roll up adherence by trading desk',
];
